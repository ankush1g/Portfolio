import React from "react";
import "./about.css";
import Me from "../../Assets/me.png";
import Dp from "../../Assets/resume.pdf";

export default function about() {
  return (
    <section className="about container" id="about">
      <h2 className="section_title">About Me</h2>
      <div className="about_container grid">
        <img src={Me} alt="" className="about_img" />
        <div className="about_data grid">
          <div className="about_info">
            <p className="about_description">
              Hi, I am Ankush Garg, Pursuing B.Tech From Maharishi Markendeshwar
              University and My Specialization in CSE. I Having Experience in
              Web Designing Frontend Development And Building And Customizing
              all types of Frontend Websites. I am knowledgeable in DSA, Java,
              Python, MySql, HTML , CSS, JavaScript, ReactJs, Python etc.
            </p>
            <a href={Dp} download className="btn">
              Download CV
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
