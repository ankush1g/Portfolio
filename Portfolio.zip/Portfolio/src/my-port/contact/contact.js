import React from "react";
import "./contact.css";
import emailjs from "@emailjs/browser";
export default function contact() {
  function sendEmail(e) {
    e.preventDefault();
    emailjs.sendForm(
      "service_u919q97",
      "template_n8wceyp",
      e.target,
      "uN6XAwwTzSRlg6WhU"
    ).then(res=>{
      console.log(res);
    }).catch(err=>console.log(err));
  }
  return (
    <section className="section container contact" id="contact">
      <h1 className="section_title">Contact Me</h1>
      <div className="contact_container grid">
        <div className="contact_info">
          <h3 className="contact_title">Let's Talk</h3>
          <p className="contact_details">Don't like forms? Send me Email</p>
        </div>
        <form action="" className="contact_form" onSubmit={sendEmail}>
          <div className="contact_form-group">
            <div className="contact_form-div">
              <input
                type="text"
                className="contact_input"
                placeholder="Enter Your Name"
                name="name"
              />
            </div>
            <div className="contact_form-div">
              <input
                type="email"
                className="contact_input"
                placeholder="Enter Your Email"
                name="email"
              />
            </div>
          </div>
          <div className="contact_form-div">
            <input
              type="text"
              className="contact_input"
              placeholder="Enter Your Subject"
            />
          </div>
          <div className="contact_form-div contact_form-area">
            <textarea
              name="subject"
              id=""
              cols="30"
              rows="5"
              className="contact_input"
              placeholder="Enter What you write"
            ></textarea>
          </div>

          <button className="btn">Send Message</button>
        </form>
      </div>
    </section>
  );
}
