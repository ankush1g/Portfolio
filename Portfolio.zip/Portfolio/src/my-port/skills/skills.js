import React from "react";
import "./skills.css";

export default function skills() {
  return (
    <section className="skills section container" id="Skills">
      <h2 className="section_title skil">Skills</h2>
      <div className="skills_container">
        <div className="about_skills grid">
          <div className="skills_data">
            <div className="skills_titles">
              <h3 className="skills_name">Development</h3>
            </div>
            <div className="skills_bar">
              <span className="skills_percentage development"></span>
            </div>
          </div>
        </div>

        <div className="about_skills grid">
          <div className="skills_data">
            <div className="skills_titles">
              <h3 className="skills_name">Java</h3>
            </div>
            <div className="skills_bar">
              <span className="skills_percentage java"></span>
            </div>
          </div>
        </div>

        <div className="about_skills grid">
          <div className="skills_data">
            <div className="skills_titles">
              <h3 className="skills_name">Python</h3>
            </div>
            <div className="skills_bar">
              <span className="skills_percentage python"></span>
            </div>
          </div>
        </div>

        <div className="about_skills grid">
          <div className="skills_data">
            <div className="skills_titles">
              <h3 className="skills_name">Python</h3>
            </div>
            <div className="skills_bar">
              <span className="skills_percentage python"></span>
            </div>
          </div>
        </div>

        <div className="about_skills grid">
          <div className="skills_data">
            <div className="skills_titles">
              <h3 className="skills_name">DSA</h3>
              <span className="skills_number"></span>
            </div>
            <div className="skills_bar">
              <span className="skills_percentage dsa"></span>
            </div>
          </div>
        </div>

        <div className="about_skills grid">
          <div className="skills_data">
            <div className="skills_titles">
              <h3 className="skills_name">MySQL</h3>
              <span className="skills_number"></span>
            </div>
            <div className="skills_bar">
              <span className="skills_percentage mysql"></span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
