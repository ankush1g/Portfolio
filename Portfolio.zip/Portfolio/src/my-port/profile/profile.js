import React from "react";
import "./profile.css";
import Me from "../../Assets/me.png";
// import ScrollDown from "./ScrollDown"

export default function profile() {
  return (
    <section className="home container" id="home">
      <div className="intro">
        <img src={Me} alt="" className="home_img" />
        <h1 className="home_name">Ankush Garg</h1>
        <span className="home_education">I'm Full Stack Developer</span>
        <div className="home_socials">
        <a href="https://www.instagram.com/_ankush1/" className="home_social-link" target="_blank">
        <i className="icon-social-instagram"></i>
        </a>
        <a href="https://github.com/ankush1g" className="home_social-link" target="_blank">
        <i className="icon-social-github"></i>
        </a>
        <a href="https://www.linkedin.com/in/ankush-garg-486545232" className="home_social-link" target="_blank">
        <i className="icon-social-linkedin"></i>
        </a>
        <a href="" className="home_social-link" target="_blank">
        <i className="icon-social-google"></i>
        </a>
        <a href="https://twitter.com/agarg0796" className="home_social-link" target="_blank" aria-disabled>
        <i className="icon-social-twitter"></i>
        </a>
    </div>

        <div className="bttn1">
        <a href="#contact" className="btn">
          Hire Me
        </a>
        </div>
      </div>
      {/* <ScrollDown/> */}
    </section>
  );
}
