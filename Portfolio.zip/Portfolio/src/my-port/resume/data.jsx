const data=[
    {
        id:1,
        category:"education",
        icon:"icon-graduation",
        year:"2018 - Pass-Out",
        title:"Secondary School",
        desc:"Percentage: 56%",
    },
{
    id:2,
    category:"experience",
    icon:"icon-briefcase",
    year:"2022",
    title:"No Experience",
    desc:"lorem",
},
{
    id:3,
    category:"education",
    icon:"icon-graduation",
    year:" 2018-2021",
    title:"DIPLOMA",
    desc:"  Diploma:Computer Science Engineering  \n Percentage: 74.56%",
}
,
{
    id:1,
    category:"education",
    icon:"icon-graduation",
    year:"2022 - present",
    title:"B-TECH",
    desc:"BTech: Computer Science Engineering \n Pursuing",
},
{
    id:2,
    category:"experience",
    icon:"icon-briefcase",
    year:"2022",
    title:"No Experience",
    desc:"lorem",
},
{
    id:3,
    category:"experience",
    icon:"icon-briefcase",
    year:"2022",
    title:"No Experience",
    desc:"lorem",
}
];


export default data