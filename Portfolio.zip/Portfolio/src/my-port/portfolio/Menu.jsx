import work1 from "../../Assets/AK.png";
import portfolio from "../../Assets/portfolio.jpeg";
const Menu=[
    {
        id:1,
        image:portfolio,
        title:"My Own Portfolio",
        category:"WebSite",
    },
    {
        id:1,
        image:work1,
        title:"project Portfolio",
        category:"Art",
    },
    {
        id:1,
        image:work1,
        title:"project Portfolio",
        category:"Branding",
    },
    {
        id:1,
        image:work1,
        title:"project Portfolio",
        category:"Design",
    },{
        id:1,
        image:work1,
        title:"project Portfolio",
        category:"Branding",
    },
    {
        id:1,
        image:work1,
        title:"project Portfolio",
        category:"Design",
    }
];

export default Menu