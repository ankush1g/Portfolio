import Navbar from "./my-port/Navbar/navbar.js";
import Profile from "./my-port/profile/profile.js";
import About from "./my-port/bout/about.js";
import Skills from "./my-port/skills/skills.js";
import Resume from "./my-port/resume/resume.js";
import Portfolio from "./my-port/portfolio/portfolio.js";
import Contact from "./my-port/contact/contact.js";
import './App.css';

function App() {
  return (
    <div>
      <Navbar/>
      <main className="main">
        <Profile />
        <About/>
        <Skills />
        <Resume />
        <Portfolio />
        <Contact />
      </main>
    </div>
  );
}

export default App;
